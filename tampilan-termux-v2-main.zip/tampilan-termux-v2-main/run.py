#!/usr/xbin/python2
import os
import sys

os.system("bash __xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh")
